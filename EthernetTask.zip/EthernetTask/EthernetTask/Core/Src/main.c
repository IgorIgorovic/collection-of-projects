/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <math.h>
#include "EtherShield.h"
#include "st7735.h"
#include "fonts.h"
#define NETBUFSIZE 1024
#define RESULTS_CAPTIONS_SIZE 2000
#define RESULTS_DESCRIPTIONS_SIZE 4000

uint8_t netBuf[NETBUFSIZE];// net buffer for ethernet library
//uint8_t htmlCodeNow;
uint8_t resultsCaptions[RESULTS_CAPTIONS_SIZE];// array of different search result captions
uint8_t resultsDescriptions[RESULTS_DESCRIPTIONS_SIZE];// array of different search result descriptions
uint16_t resultIndexesCap[15];// array of start indexes of different captions, used for results output
uint16_t resultIndexesDes[15];// array of start indexes of different descriptions
uint16_t resCapInd = 0;// index where next character is placed in resultIndexesCap
uint16_t resDesInd = 0;// the same but resultIndexesDes
uint8_t resultCountDes = 0;// captions count
uint8_t resultCountCap = 0;
uint8_t currentDisplayedRes = 0;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;

PCD_HandleTypeDef hpcd_USB_OTG_FS;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI2_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//        ---get time from time.is---
//void result_cb(uint8_t stcode, uint16_t offset, uint16_t len){
//	uint8_t hour,minute,second;
//	uint8_t usbBuf[9];
//
//	for(uint16_t i=0;i<(offset+len-3);i++){
//		usbBuf[0] = netBuf[i];
//	    usbBuf[1] = netBuf[i+1];
//		usbBuf[2] = netBuf[i+2];
//		usbBuf[3] = netBuf[i+3];
//		if(usbBuf[0]=='D' && usbBuf[1]=='a' &&usbBuf[2]=='t' && usbBuf[3] =='e'){
//			hour = ( (netBuf[i+23] - 48)*10 + (netBuf[i+24] - 48) ) + 3;
//			minute = (netBuf[i+26] - 48)*10 + (netBuf[i+27] - 48);
//			second = (netBuf[i+29] - 48)*10 + (netBuf[i+30] - 48);
//			sprintf(usbBuf, "%d %d %d", hour, minute, second);
//			CDC_Transmit_FS(usbBuf, 8);
//			break;
//	    }
//	}
//}
uint8_t ReadEnc() {
	uint8_t S1;
	uint8_t S2;
	uint8_t KEY;
	static uint8_t prevS1;
	static uint8_t prevS2;
	static uint8_t prevKEY;
	uint8_t res = 0;

	S1 = GPIOA->IDR & Encoder_S1_Pin;
	S2 = GPIOA->IDR & Encoder_S2_Pin;
	KEY = GPIOA->IDR & Encoder_KEY_Pin;
	//rotation
	if (S1 && !prevS1) {
		if (S2) {
			res = 'r';
		}
		else {
			res = 'l';
		}
	}
	//button press
	else if (!KEY && prevKEY) {
		res = 'b';
	}
	prevS1 = S1;
	prevS2 = S2;
	prevKEY = KEY;
	return res;
}
//needed to be: if num=0 - 0, 1 - resultIndexesCap[0], 2 - resultIndexesCap[1]...
void replaceCyrylic(int16_t cyrylicnum, uint8_t *rpl){
	uint8_t isBig = (cyrylicnum >= 1040 && cyrylicnum <= 1065)? 1: 0;
	if(isBig){
		cyrylicnum += 32;//the most of big cyrillic letters are converted to the small ones here
	}
	switch(cyrylicnum){
	//small cyrillic letters are replaced with latin ones here
	case 1072: rpl[0]='a';break;
	case 1073: rpl[0]='b';break;
	case 1074: rpl[0]='v';break;
	case 1075: rpl[0]='h';break;
	case 1076: rpl[0]='d';break;
	case 1077: rpl[0]='e';break;
	case 1078: rpl[0]='z';rpl[1]='h';break;
	case 1079: rpl[0]='z';break;
	case 1080: rpl[0]='y';break;
	case 1081: rpl[0]='j';break;
	case 1082: rpl[0]='k';break;
	case 1083: rpl[0]='l';break;
	case 1084: rpl[0]='m';break;
	case 1085: rpl[0]='n';break;
	case 1086: rpl[0]='o';break;
	case 1087: rpl[0]='p';break;
	case 1088: rpl[0]='r';break;
	case 1089: rpl[0]='s';break;
	case 1090: rpl[0]='t';break;
	case 1091: rpl[0]='u';break;
	case 1092: rpl[0]='f';break;
	case 1093: rpl[0]='k';rpl[1]='h';break;
	case 1094: rpl[0]='t';rpl[1]='s';break;
	case 1095: rpl[0]='c';rpl[1]='h';break;
	case 1096: rpl[0]='s';rpl[1]='h';break;
	case 1097: rpl[0]='s';rpl[1]='h';rpl[2]='c';rpl[3]='h';break;

	case 1100: rpl[0]=39;break;// the soft sign is represented by '
	case 1099: rpl[0]='y';break;// russian ьі
	case 1108: rpl[0]='i';rpl[1]='e';break;
	case 1102: rpl[0]='i';rpl[1]='u';break;
	case 1103: rpl[0]='i';rpl[1]='a';break;
	case 1110: rpl[0]='i';break;
	case 1111: rpl[0]='j';rpl[1]='i';break;
	case 1169: rpl[0]='g';break;
	//some big letters are replaced here
	case 1068: rpl[0]=39;break;// the soft sign is represented by '
	case 1067: rpl[0]='Y';break;// russian ЬІ
	case 1028: rpl[0]='I';rpl[1]='E';break;
	case 1070: rpl[0]='I';rpl[1]='U';break;
	case 1071: rpl[0]='I';rpl[1]='A';break;
	case 1030: rpl[0]='I';break;
	case 1031: rpl[0]='J';rpl[1]='I';break;
	case 1168: rpl[0]='G';break;
	default: rpl[0]='*';break;
	}
	if(isBig){
		for(uint8_t i=0;i<4;i++){
			if(rpl[i]){
				rpl[i] -= 32;
			}
		}
	}

}
void outputResult(uint8_t num){
	uint8_t *captionPtr = & resultsCaptions[ num > 0? resultIndexesCap[num-1]: 0 ];
	uint8_t *descriptionPtr = & resultsDescriptions[ num > 0? resultIndexesDes[num]: 0 ];
	//add offset between caption and description
	uint8_t count = 0;
	uint8_t *i=captionPtr;
	while(*i){
		count++;
		i++;
	}
	uint16_t lastLineY = 0;
	ST7735_DrawString(0, 0, captionPtr, Font_7x10, ST7735_RED, ST7735_BLACK);
	lastLineY = rint(count/18.0)*10+10;
	ST7735_DrawString(0, lastLineY, descriptionPtr, Font_7x10, ST7735_WHITE, ST7735_BLACK);
}
//in tests, on STM32F401CEU6 at 60MHz it takes up to 1 ms to execute html_parser function
void html_parser(uint8_t statuscode, uint16_t offset, uint16_t length){
	static uint8_t neededTag1[] = "div class=\"BNeawe s3v9rd AP7Wnd\"";// description tag
	static uint8_t neededTag2[] = "div class=\"BNeawe vvjwJb AP7Wnd\"";// caption tag
	static uint8_t tagsMaxLength = sizeof neededTag1/sizeof neededTag1[0]-1;
	static uint8_t closingTag[] = "div";
	static uint8_t closingTagLen = sizeof closingTag/sizeof closingTag[0]-1;
	//flags
	static uint8_t copyIntoRes = 0;
	static uint8_t reachedNeededTag;
	static uint8_t reachedClosingTag;
	static uint8_t tagsInsideContent = 0;
	static uint8_t isPageDescription = 0;
	static uint8_t firstCptAdded = 0;
	static uint8_t cyrylicOnPage[4];
	static uint16_t cyrylic = 0;
	static uint8_t reachedAmprsndBefore = 0;
	//main loop
	for(uint16_t i=offset;i<(length+offset);i++){
		if(netBuf[i-1]=='<'){
			// check if the closing tag is the one we need to copy text from (in this case, </div>)
			if(netBuf[i] == '/' && copyIntoRes) {
				reachedClosingTag = 1;
				for(uint16_t j=i+1; j < (i+1+closingTagLen); j++) {
					if(netBuf[j] != closingTag[j-i-1]){
						reachedClosingTag = 0;
					}
				}
				//if yes, stop copying text from it
				if(reachedClosingTag) {
					copyIntoRes = 0;
					//set last character to zero
					if(!isPageDescription){
						resultsCaptions[resCapInd++] = 0;
					    firstCptAdded = 1;
					    resultIndexesCap[resultCountCap++] = resCapInd;
					}
					else if(firstCptAdded){
						resultsDescriptions[resDesInd++] = 0;
						resultIndexesDes[resultCountDes++] = resDesInd;
					}
			    }
		    }
			//else, check if we found the needed tag
		    reachedNeededTag = 1;
		    for(uint16_t j=i; (j < i+tagsMaxLength) && reachedNeededTag; j++) {
		    	if(netBuf[j] != neededTag1[j-i]){ reachedNeededTag = 0; }
		    }
		    //if we didn't find description tag, look for caption's one
		    if(!reachedNeededTag && !copyIntoRes){
		    	reachedNeededTag = 1;
		    	isPageDescription = 0;
		    	for(uint16_t j=i; (j < i+tagsMaxLength) && reachedNeededTag; j++) {
		    	    if(netBuf[j] != neededTag2[j-i]){ reachedNeededTag = 0; }
		        }
		    }
		    else{ isPageDescription = 1;}
		    //if yes, start copying the data and increase the count
 		    if(reachedNeededTag) {
 				copyIntoRes = 1;
 				i += tagsMaxLength + 1;
 				tagsInsideContent = 0;
 				//count++;
	        }
		}// if netBuf[i-1] == '<'

		if(copyIntoRes){//here are some code to prevent tags inside the text we need appear in the results
			if(netBuf[i] == '<'){ tagsInsideContent = 1; }
			else if(netBuf[i] == '>'){ tagsInsideContent = 0; continue; }
			//cyrylic replacement
			if(!tagsInsideContent){
				if(netBuf[i] == '&'){
					reachedAmprsndBefore = 1;//this code is added because cyrillic(&#1234) sometimes
					                         //is divided between Ethernet packets
				}
				if(reachedAmprsndBefore&&(netBuf[i] == '#'||netBuf[i+1] == '#')&&
				        ((isPageDescription&&firstCptAdded)||!isPageDescription) ){
					if(netBuf[i] == '#'){ i--; }
				    cyrylicOnPage[0]=0;
				    cyrylicOnPage[1]=0;
				    cyrylicOnPage[2]=0;
				    cyrylicOnPage[3]=0;
				    for(uint8_t j=0;j<4;j++){
					    if(netBuf[i+2+j] == ';'){
					    	break;
					    }
					    else{
						    cyrylicOnPage[3-j] = netBuf[i+2+j];
					    }
				    }
				    cyrylic=(cyrylicOnPage[3]-48)*1000 +(cyrylicOnPage[2]-48)*100
				        	  +(cyrylicOnPage[1]-48)*10 + cyrylicOnPage[0]-48;
				    uint8_t cyrylicReplacement[] = {0,0,0,0};
				    replaceCyrylic(cyrylic, cyrylicReplacement);
				    uint8_t *resultsPtr = isPageDescription ? &resultsDescriptions[resDesInd]:
						                  &resultsCaptions[resCapInd];
				    uint16_t *resInd = isPageDescription ? &resDesInd: &resCapInd;
					
				    for(uint8_t j=0;j<4;j++){
				    	if(cyrylicReplacement[1]){
				    		HAL_GetTick();
				    	}
					    if(cyrylicReplacement[j]){
					    	*resultsPtr = cyrylicReplacement[j];
					    	resultsPtr++;
					    	*resInd = *resInd + 1;
					    }
				    }
				    i = i + (cyrylicOnPage[0] ? 6:5);//this is for skipping cyrylic(&#1234;)
				                                     //in main cycle after we handle cyrylic letter
				    reachedAmprsndBefore = 0;
				    continue;
			    }
				if(!isPageDescription && resCapInd < RESULTS_CAPTIONS_SIZE){
					resultsCaptions[resCapInd++] = netBuf[i];
				}
				else if(resDesInd < RESULTS_DESCRIPTIONS_SIZE && firstCptAdded){
					resultsDescriptions[resDesInd++] = netBuf[i];
				}
			}// if(!tagsInsideContent)
		}// if(copyIntoRes)
	}//main cycle
}//tag_searcher
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_USB_OTG_FS_PCD_Init();
  /* USER CODE BEGIN 2 */
  ST7735_Init();
  ST7735_Backlight_On();
  ST7735_SetRotation(0);
  ST7735_FillScreen(ST7735_BLACK);
  uint8_t local_ip[4];
  uint8_t local_mac[] = {0x02, 0x03, 0x04, 0x05, 0x06, 0x09};
  uint8_t local_netMask[4];
  uint8_t local_gateIp[4];
  uint8_t local_dnsIp[4];
  uint8_t local_dhcpServerIp[4];
  uint8_t website[] = "www.google.com";
  //uint8_t website_ip[] = {192,168,7,14};

  ES_enc28j60SpiInit(&hspi1);
  ES_enc28j60Init(local_mac);

  //uint8_t enc28j60_rev = ES_enc28j60Revision();
  allocateIPAddress(netBuf, NETBUFSIZE, local_mac, 80, local_ip, local_netMask,
		  local_gateIp, local_dnsIp, local_dhcpServerIp);
  //client_tcp_set_serverip(website_ip);
  resolveHostname(netBuf, NETBUFSIZE, website);
  client_http_get("https://www.google.com", "search?q=kitten", website, html_parser);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  packetloop_icmp_tcp(netBuf, enc28j60PacketReceive(1500, netBuf));
	  if(uwTick == 12000){
		  outputResult(currentDisplayedRes);
	  }
	  if(uwTick >= 12000){
		  uint8_t encVal = ReadEnc();
		  if(encVal == 'r' && currentDisplayedRes < resultCountCap){
			  ST7735_FillScreen(ST7735_BLACK);
			  outputResult(++currentDisplayedRes);
		  }
		  else if(encVal == 'l' && currentDisplayedRes > 0){
			  ST7735_FillScreen(ST7735_BLACK);
			  outputResult(--currentDisplayedRes);
		  }
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 15;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 5;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Ethernet_LED_GPIO_Port, Ethernet_LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Ethernet_CS_GPIO_Port, Ethernet_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ST7735_BL_GPIO_Port, ST7735_BL_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ST7735_RES_Pin|ST7735_DC_Pin|ST7735_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : Ethernet_LED_Pin */
  GPIO_InitStruct.Pin = Ethernet_LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Ethernet_LED_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : Encoder_KEY_Pin Encoder_S2_Pin Encoder_S1_Pin */
  GPIO_InitStruct.Pin = Encoder_KEY_Pin|Encoder_S2_Pin|Encoder_S1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : Ethernet_CS_Pin */
  GPIO_InitStruct.Pin = Ethernet_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Ethernet_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ST7735_BL_Pin ST7735_RES_Pin ST7735_DC_Pin ST7735_CS_Pin */
  GPIO_InitStruct.Pin = ST7735_BL_Pin|ST7735_RES_Pin|ST7735_DC_Pin|ST7735_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
