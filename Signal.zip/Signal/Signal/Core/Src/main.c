/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "st7735.h"
#include "fonts.h"
#include "testimg.h"

#include "stdbool.h"
#include "string.h"
#include <math.h>

#define red transRGB16bit(200, 50, 50)
#define dark_red transRGB16bit(80, 30, 30)
#define white 0xFFFF
#define black 0x0000
#define green transRGB16bit(0, 207, 60)
uint8_t numValues[7] = { 0, 0, 0, 0, 0, 0, 0 };//frequency value
bool S1, S2, KEY;
bool prevS1, prevS2, prevKEY;
uint32_t tmrEnc = 0;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/*  a function which returns 'r or 'l' uint8_t symbol when encoder rotates
 * and 'b' when encoder button is pressed  */
uint8_t ReadEnc() {
	S1 = GPIOB->IDR & S1_Pin;
	S2 = GPIOB->IDR & S2_Pin;
	KEY = GPIOB->IDR & KEY_Pin;
	//rotation
	if (S1 && !prevS1) {
		if (S2) {
			return 'r';
		}
		else {
			return 'l';
		}
	}
	//button press
	if (!KEY && prevKEY) {
		return 'b';
	}
	return 0;
}
/*  function for converting 24 bit rgb color into 16 bit color  */
uint16_t transRGB16bit(uint8_t r, uint8_t g, uint8_t b) {
	uint16_t r16 = rint(r * 0.1216);
	uint16_t g16 = rint(g * 0.2471);
	uint16_t b16 = rint(b * 0.1216);
	uint16_t res = 0x0000;
	res = res | b16;
	res = res | (g16 << 5);
	res = res | (r16 << 11);
	return res;
}
/*  draw main menu when it is entered  */
void drawMainMenu(){
	ST7735_FillScreen(dark_red);
	ST7735_FillRectangle(0, 0, 160, 30, red);                             //banner
	ST7735_DrawString(31, 6, "Main menu", Font_11x18, white, red);        //
	ST7735_DrawString(40, 35, "You can set:", Font_7x10, white, dark_red);//

	ST7735_FillRoundRect(12, 50, 135, 30, 5, white);                    //button 1
	ST7735_DrawString(12, 58, "Signal shape", Font_11x18, black, white);//

	ST7735_FillRoundRect(12, 90, 135, 30, 5, red);                    //button 2
	ST7735_DrawString(30, 96, "Frequency", Font_11x18, black, red);   //
}
/*  draw signal shape menu when it is entered  */
void drawSigShapeMenu(){
	ST7735_FillScreen(dark_red);
	ST7735_FillRectangle(0, 0, 160, 30, red);                        // banner
	ST7735_DrawRoundRect(3, 3, 20, 20, 2, black);                    //button BACK
	ST7735_FillTriangle(5, 13, 19, 5, 19, 20, black);                //
	ST7735_DrawString(25, 6, "Signal shape", Font_11x18, white, red);//

	ST7735_FillRoundRect(5, 40, 80, 20, 5, white);                //button 1
	ST7735_DrawString(17, 45, "Sinusoid", Font_7x10, black, white);//

	ST7735_FillRoundRect(5, 70, 80, 20, 5, red);                  //button 2
	ST7735_DrawString(35, 75, "Saw", Font_7x10, white, red);       //

	ST7735_FillRoundRect(5, 100, 80, 20, 5, red);                  //button 3
	ST7735_DrawString(21, 105, "Meander", Font_7x10, white, red);  //
	//sinusoid

	uint8_t px = 95;
	uint8_t py = 50;
	//sinusoid
	float angles[] = { 16.3, 32.7, 49.0, 65.4, 81.8, 98.1, 114.5, 130.9, 147.2, 163.6, 180.0};
	float angle = 0;
	for(uint8_t i=0;i<5;i++){
		if(i%2==0){
			for(uint8_t j=0;j<11;j++){
				angle = angles[j];
				//angle = angle + j*16.36;
				py = 50 - rint(sinf( angle * 3.141592 /180 ) * 10);
				ST7735_DrawPixel(px, py, white);
				px++;
			}
		}
		else{
			for(uint8_t j=0;j<11;j++){
				angle = angles[j];
				py = 50 + rint(sinf( angle * 3.141592 /180 ) * 10);
				ST7735_DrawPixel(px, py, white);
				px++;
		    }
		}
	}
	//saw
	for(uint8_t i=0;i<5;i++){
		if(i%2==0){
			ST7735_DrawLine(95+i*11, 90, 95+(i+1)*11, 70, white);
		}
		else{
			ST7735_DrawLine(95+i*11, 70, 95+(i+1)*11, 90, white);
		}
	}
	//meander
	for(uint8_t i=0;i<5;i++){
		if(i%2==0){
			ST7735_DrawFastHLine(95+i*11, 100, 11, white);
	        ST7735_DrawFastVLine(95+(i+1)*11, 100, 20, white);  }
		else {
			ST7735_DrawFastVLine(95+(i+1)*11, 100, 20, white);
			ST7735_DrawFastHLine(95+i*11, 120, 11, white);  }
	}

}
/*  draw frequency menu when it is entered  */
void drawFreqMenu(){
	ST7735_FillScreen(dark_red);
	ST7735_FillRectangle(0, 0, 160, 40, red); //banner
	ST7735_DrawRoundRect(5, 5, 30, 30, 5, black); //back button
	ST7735_FillTriangle(10, 20, 25, 10, 25, 30, black); //triangle on button
	ST7735_DrawString(45, 13, "Frequency", Font_11x18, white, red);

	uint8_t v;
	for (uint8_t i = 0; i < 7; i++) {
		v = numValues[i];
		ST7735_DrawString(5 + i * (16 + 5), 60,
		v==0?"0":(v==1?"1":(v==2?"2":(v==3?"3":(v==4?"4":(v==5?"5":(v==6?"6":(v==7?"7":(v==8?"8":"9")))))))),
		Font_16x26, white, dark_red); //frequency
	}
	ST7735_DrawString(105, 96, "(Hz)", Font_11x18, white, dark_red);
	ST7735_FillRoundRect(15, 92, 70, 30, 5, red); //OK button
	ST7735_DrawString(39, 98, "OK", Font_11x18, white, red);
}
/*  function for sending 16 bits to AD9833. This chip needs to get a 16 bit word every data transfer */
void spiWrite16(uint16_t data){
	GPIOB->BSRR = CLK_Pin;
	GPIOB->BSRR = CS_Pin<<16;
	for(uint8_t i=0;i<16;i++){
		if(data & 0x8000){GPIOB->BSRR = MOSI_Pin;}
		else{GPIOB->BSRR = MOSI_Pin<<16;}

		GPIOB->BSRR = CLK_Pin<<16;
		data = data<<1;
		if(data & 0x8000){}
		GPIOB->BSRR = CLK_Pin;
	}
	GPIOB->BSRR = CS_Pin;
	GPIOB->BSRR = MOSI_Pin<<16;
}
/*  function for changing frequency register  */
void freqWrite(uint32_t data, uint8_t reg){// data: 0000, then 28 bits of register data
	uint16_t addr;
	uint16_t msg;
	if(reg){addr = 0x8000;}
	else{addr = 0x4000;}

	msg = addr | (uint16_t) (data & 0x00003FFF);
	spiWrite16(msg);
	msg = addr | (uint16_t) (data>>14);
	spiWrite16(msg);
}
/*  function for changing phase register  */
void phaseWrite(uint16_t data, uint8_t reg){
	uint16_t msg = 0xC000 | (reg<<13) | data; // 11, reg No., 0, data(12 bit)
	spiWrite16(msg);
}
/*  menu logic  */
void InterfaceReaction(char event) {
	static uint8_t menuWind = 1;
	static uint8_t elementsInWind[] = { 7, 1, 2 };// maximum value of any element's index in different menu windows
	static uint8_t currEl = 0;
	static uint32_t frequency;

	static bool NumChoosen = 0;//is any number choosen (to be changed)

	if (!event) {return;}
	if (menuWind == 0) {
	// START   IF(MENUWIND == 0)
		if (event == 'l') {//if encoder was turned left
			//move cursor
			if(!NumChoosen && currEl == elementsInWind[menuWind]){
				currEl--;
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, white);
				ST7735_FillRoundRect(15, 92, 70, 30, 5, red); //OK button
			    ST7735_DrawString(39, 98, "OK", Font_11x18, white, red);
			}
		   else if (!NumChoosen && currEl > 0 && currEl < 255) {
			     ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, dark_red);//delete old one
				 currEl--;
				 ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, white);//draw replaced one
			}
			else if(!NumChoosen && currEl == 0){
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, dark_red);// delete cursor
				currEl=255;//255 - 'BACK' button
				//select 'BACK' button
				ST7735_DrawRoundRect(5, 5, 30, 30, 5, white);
				ST7735_FillTriangle(10, 20, 25, 10, 25, 30, white);
			}

			//or decrement number
			else if(NumChoosen && numValues[currEl] > 0){
				numValues[currEl]--;
				uint8_t v = numValues[currEl];
				ST7735_DrawString(5 + currEl * (16 + 5), 60,
				v==0?"0":(v==1?"1":(v==2?"2":(v==3?"3":(v==4?"4":(v==5?"5":(v==6?"6":(v==7?"7":(v==8?"8":"9")))))))),
				Font_16x26, white, dark_red);
			}
		}
		else if (event == 'r') {//if encoder was turned right
			// move cursor
			if (!NumChoosen && currEl < elementsInWind[menuWind]-1) {
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, dark_red);
				currEl++;
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, white);
			}//select OK button
			else if(!NumChoosen && currEl == elementsInWind[menuWind]-1){
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, dark_red);
				currEl++;
				ST7735_FillRoundRect(15, 92, 70, 30, 5, white); //OK button
			    ST7735_DrawString(39, 98, "OK", Font_11x18, black, white);
			}//deselect 'BACK' button
			else if(!NumChoosen && currEl == 255){
				currEl=0;
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, white);// draw cursor

				ST7735_DrawRoundRect(5, 5, 30, 30, 5, black);
				ST7735_FillTriangle(10, 20, 25, 10, 25, 30, black);
			}
			//or increment number
			else if(NumChoosen && numValues[currEl] < 9){
				numValues[currEl]++;
				uint8_t v = numValues[currEl];
				ST7735_DrawString(5 + currEl * (16 + 5), 60,
				v==0?"0":(v==1?"1":(v==2?"2":(v==3?"3":(v==4?"4":(v==5?"5":(v==6?"6":(v==7?"7":(v==8?"8":"9")))))))),
				Font_16x26, white, dark_red);
			}
		}
		else if (event == 'b') {// if button was pressed
			//delete cursor, select number
			if (NumChoosen) {
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, white);
				ST7735_FillRectangle(5 + currEl * (16 + 5), 60, 16, 26, dark_red);
				uint8_t v = numValues[currEl];
				ST7735_DrawString(5 + currEl * (16 + 5), 60,
			    v==0?"0":(v==1?"1":(v==2?"2":(v==3?"3":(v==4?"4":(v==5?"5":(v==6?"6":(v==7?"7":(v==8?"8":"9")))))))),
				Font_16x26, white, dark_red);

				NumChoosen = 0;
			}
			else if(currEl==elementsInWind[menuWind]){
				frequency = 0;
				for(uint8_t i=0;i<7;i++){
					frequency += (uint32_t)numValues[i] * (uint32_t)rint(pow(10.0, (6.0-i)));
				}
				frequency = (uint32_t)rint((double)frequency *268435456/25000000);
				freqWrite(frequency, 0);
				ST7735_FillRoundRect(15, 92, 70, 30, 5, green); //OK button
				ST7735_DrawString(39, 98, "OK", Font_11x18, white, green);
			}
			// go to main menu
			else if(currEl == 255){
				currEl = 0;
				menuWind = 1;
				drawMainMenu();
			}
			//draw cursor, disselect number
			else {
				ST7735_FillRectangle(5 + currEl * (16 + 5), 86, 16, 5, dark_red);
				ST7735_FillRectangle(5 + currEl * (16 + 5), 60, 16, 26, white);
				uint8_t v = numValues[currEl];
				ST7735_DrawString(5 + currEl * (16 + 5), 60,
				v==0?"0":(v==1?"1":(v==2?"2":(v==3?"3":(v==4?"4":(v==5?"5":(v==6?"6":(v==7?"7":(v==8?"8":"9")))))))),
				Font_16x26, black, white);

				NumChoosen = 1;
			}
		}
	}
	//END   IF (MENUWIND) == 0
	else if(menuWind == 1){
	// START IF(MENUWIND == 1)
		if(event == 'l' && currEl > 0){
			currEl--;
			ST7735_FillRoundRect(12, 50, 135, 30, 5, white);
			ST7735_DrawString(12, 58, "Signal shape", Font_11x18, black, white);
			ST7735_FillRoundRect(12, 90, 135, 30, 5, red);
			ST7735_DrawString(30, 96, "Frequency", Font_11x18, black, red);
		}
		else if(event == 'r' && currEl < elementsInWind[menuWind]){
			currEl++;
			ST7735_FillRoundRect(12, 50, 135, 30, 5, red);
			ST7735_DrawString(12, 58, "Signal shape", Font_11x18, black, red);
		    ST7735_FillRoundRect(12, 90, 135, 30, 5, white);
			ST7735_DrawString(30, 96, "Frequency", Font_11x18, black, white);
		}
		else if(event == 'b'){
			if(currEl == 0){
				//go to signal shape menu
				menuWind = 2;
				drawSigShapeMenu();
			}
			else{//go to frequency menu
				currEl=0;
				menuWind = 0;
				NumChoosen = 0;
				drawFreqMenu();
			}
		}
	}
	// END IF(MENUWIND == 1)
	else if(menuWind == 2){
	//START IF(MENUWIND == 2)
		uint8_t elY[3] = {40, 70, 100};
		uint8_t elTextX[3] = {17, 35, 21};
		uint8_t elTextY[3] = {45, 75, 105};

		if((event == 'l' && currEl > 0 && currEl < 255) || (event == 'r' && currEl < elementsInWind[menuWind])){
			// disselect previous element
			ST7735_FillRoundRect(5, elY[currEl], 80, 20, 5, red);                //button 1
			ST7735_DrawString(elTextX[currEl], elTextY[currEl],
					currEl==0? "Sinusoid": (currEl==1? "Saw" : "Meander"), Font_7x10, white, red);

			if(event == 'l'){currEl--;}
			else if (event == 'r' ){currEl++;}
			// select new
			ST7735_FillRoundRect(5, elY[currEl], 80, 20, 5, white);                //button 1
			ST7735_DrawString(elTextX[currEl], elTextY[currEl],
					currEl==0? "Sinusoid": (currEl==1? "Saw" : "Meander"), Font_7x10, black, white);

		}
		else if(event == 'r' && currEl ==255){
			//disselect BACK button
			currEl = 0;
			ST7735_FillRoundRect(5, 40, 80, 20, 5, white);               //button 1
			ST7735_DrawString(17, 45, "Sinusoid", Font_7x10, red, white);//
			ST7735_DrawRoundRect(3, 3, 20, 20, 2, black);                //button BACK
			ST7735_FillTriangle(5, 13, 19, 5, 19, 20, black);            //
		}
		else if(event == 'l' && currEl == 0){
			currEl = 255;
			ST7735_FillRoundRect(5, 40, 80, 20, 5, red);                 //button 1
			ST7735_DrawString(17, 45, "Sinusoid", Font_7x10, white, red);//
			ST7735_DrawRoundRect(3, 3, 20, 20, 2, white);                //button BACK
			ST7735_FillTriangle(5, 13, 19, 5, 19, 20, white);            //
		}
		else if(event == 'b'){

			// go to main menu
			if(currEl == 255){
				currEl = 0;
				menuWind = 1;
				drawMainMenu();
			}
			//or select element
			else{
				ST7735_FillRoundRect(5, elY[currEl], 80, 20, 5, green);
				ST7735_DrawString(elTextX[currEl], elTextY[currEl],
						currEl==0? "Sinusoid": (currEl==1? "Saw" : "Meander"), Font_7x10, black, green);
				spiWrite16(currEl==0? 0x2000: (currEl==1? 0x2002: 0x2028));
			}
		}
	}
	// END IF(MENUWIND == 2)
}
/*
 Control register(when project starts)
 * 0
 * 0
 * NotDividedfreqReg 1
 * freqMSBsNow 0
 *
 * freqRegNo 0
 * phaseRegNo 0
 * 0
 * Reset 0
 *
 * IntClkDisable 0
 * DacDisable 0
 * Opbiten 1
 * 0
 *
 * DIV2 1
 * 0
 * Mode 0
 * 0
*/
/*  function for initialization of AD9833  */
void ad9833Init(uint16_t control, uint32_t freq0, uint16_t phase0, uint32_t freq1, uint16_t phase1){
	//control: 00, then 14 control bits
	spiWrite16(control | 0x0100);
	freqWrite(freq0, 0);
	freqWrite(freq1, 1);
	phaseWrite(phase0, 0);
	phaseWrite(phase1, 1);
	spiWrite16(control & 0xFEFF);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
	prevS1 = GPIOB->IDR & S1_Pin;
	prevS2 = GPIOB->IDR & S2_Pin;
	prevKEY = GPIOB->IDR & KEY_Pin;

	ST7735_Init();
	ST7735_Backlight_On();
	ST7735_SetRotation(1);
	drawMainMenu();
	HAL_Delay(1);
	ad9833Init(0x2028, 0, 0, 0, 0);
	HAL_Delay(1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		InterfaceReaction(ReadEnc());
		prevS1 = S1;
		prevS2 = S2;
		prevKEY = KEY;
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 15;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 5;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, ST7735_RES_Pin|ST7735_DC_Pin|ST7735_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ST7735_BL_Pin|CS_Pin|CLK_Pin|MOSI_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : ST7735_RES_Pin ST7735_DC_Pin ST7735_CS_Pin */
  GPIO_InitStruct.Pin = ST7735_RES_Pin|ST7735_DC_Pin|ST7735_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : ST7735_BL_Pin CLK_Pin MOSI_Pin */
  GPIO_InitStruct.Pin = ST7735_BL_Pin|CLK_Pin|MOSI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : CS_Pin */
  GPIO_InitStruct.Pin = CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : KEY_Pin S2_Pin S1_Pin */
  GPIO_InitStruct.Pin = KEY_Pin|S2_Pin|S1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
