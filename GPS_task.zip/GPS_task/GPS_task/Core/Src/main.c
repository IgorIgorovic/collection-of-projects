/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "usbd_cdc_if.h"
#include "st7735.h"
#include "fonts.h"

#include <stdlib.h>
uint8_t rxbuf[650] = {0, };
uint8_t txbuf[100] = {0, };

uint8_t visSVsGPS[150];
uint8_t visSVsGLO[150];
uint8_t visSVsGPSInd=0;
uint8_t visSVsGLOInd=0;
uint8_t CoordsString[16];

uint8_t latitude[4];
uint8_t longitude[4];
int8_t NS, EW;
uint8_t gotCorrMesg;

//TODO implement checksum checking
//TODO optimize the code in some places; make it shorter(if possible); maybe make sure it works well with wrong input data;
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*
 * Some explanation how the parser works (the 'for' loop inside it)
 * In the loop body of parser of any NMEA message you will find three conditional operators:
 * the first conditional statement body is executed when we reach the end of the data field. The
 * code in it is supposed to parse the data field. the msgFieldNo variable is incremented each
 * time this statement is executed.
 *
 * the second operator else is implemented to fill buffer(buf) with content of data field so it
 * can be parsed later.
 *
 * the third operator is activated when code reaches the end of NMEA message. It sets gotCorrMesg
 * flag to 1 so that result of parsing can be used in main loop later.
 */

uint8_t parseNmeaMessage(uint8_t *msgBuf, uint16_t size){

//start of GSV parser
	if(msgBuf[3]=='G' && msgBuf[4]=='S' && msgBuf[5]=='V' && msgBuf[9]<'3'){
		uint8_t *visSVsString;//this is pointer to the buffer we write currently to
		uint8_t visSVsStrInd;//this index is index of the first character in the visSVsString which is zero.
		uint8_t buf[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		uint8_t bufInd = 0;

		uint8_t msgFieldNo = 1;
		uint8_t numOfSVs = 0;
		uint8_t SVDataFieldType = 0;
		uint16_t azimuth = 0;

		switch(msgBuf[2]) {
		case 'P':
			visSVsString = visSVsGPS;
			visSVsStrInd = visSVsGPSInd;break;
		case 'L':
			visSVsString = visSVsGLO;
			visSVsStrInd = visSVsGLOInd;break;
		case 'A':
			break;
		case 'B':
			break;
		}
		if(msgBuf[9] == '1'){
			//erase text buffer if we got a new GSV message sequence
			for(;visSVsStrInd>0; visSVsStrInd--){
				visSVsString[visSVsStrInd]=0;
			}
			visSVsString[visSVsStrInd]=0;

			switch(msgBuf[2]){
		    case 'P':
			    visSVsString[visSVsStrInd++]='G';
			    visSVsString[visSVsStrInd++]='P';
			    visSVsString[visSVsStrInd++]='S'; break;
		    case 'L':
			    visSVsString[visSVsStrInd++]='G';
			    visSVsString[visSVsStrInd++]='L';
		        visSVsString[visSVsStrInd++]='O'; break;
		    case 'A':
		    	visSVsString[visSVsStrInd++]='G';
			    visSVsString[visSVsStrInd++]='A';
			    visSVsString[visSVsStrInd++]='L'; break;
		    case 'B':
		        visSVsString[visSVsStrInd++]='B';
			    visSVsString[visSVsStrInd++]='D';
			    visSVsString[visSVsStrInd++]='S'; break;
		    }
			visSVsString[visSVsStrInd++]=' ';
		}

		//main loop
		for(uint8_t i=7;i<size;i++)
		{
			if(msgBuf[i] == ',' || msgBuf[i] == '*'){
				//parse the field of data
				if(msgFieldNo == 1){
					//No. of last message in sequence
				}
				else if(msgFieldNo == 2){
					//No. of message in sequence
				}
				else if(msgFieldNo == 3){
					numOfSVs = atoi(buf);
				}
				else if(msgFieldNo <= (3 + 4*numOfSVs) && msgFieldNo > 3){
					//parse satellite data( azimuth, CN0, etc)
					if(SVDataFieldType == 0){
						//satellite ID field
					}
					if(SVDataFieldType == 1 && buf[0]){
						//elevation
						visSVsString[visSVsStrInd++] = 'E';
						visSVsString[visSVsStrInd++] = 'L';
						visSVsString[visSVsStrInd++] = buf[0];
						visSVsString[visSVsStrInd++] = buf[1];
						visSVsString[visSVsStrInd++] = ' ';
					}
					if(SVDataFieldType == 2 && buf[0]){
						//azimuth
						visSVsString[visSVsStrInd++] = 'A';
						visSVsString[visSVsStrInd++] = 'Z';
						visSVsString[visSVsStrInd++] = '-';
						azimuth = atoi(buf);
						if(azimuth < 23 || azimuth > 337){
							visSVsString[visSVsStrInd++] = 'N';
						}
						else if(azimuth >= 23 && azimuth < 67){
							visSVsString[visSVsStrInd++] = 'N';
							visSVsString[visSVsStrInd++] = 'E';
						}
						else if(azimuth >= 67 && azimuth < 113){
							visSVsString[visSVsStrInd++] = 'E';
						}
						else if(azimuth >= 113 && azimuth < 158){
							visSVsString[visSVsStrInd++] = 'S';
							visSVsString[visSVsStrInd++] = 'E';
						}
						else if(azimuth >= 158 && azimuth < 203){
							visSVsString[visSVsStrInd++] = 'S';
						}
						else if(azimuth >= 203 && azimuth < 248){
							visSVsString[visSVsStrInd++] = 'S';
							visSVsString[visSVsStrInd++] = 'W';
						}
						else if(azimuth >= 248 && azimuth < 293){
							visSVsString[visSVsStrInd++] = 'W';
						}
						else if(azimuth >= 293 && azimuth < 338){
							visSVsString[visSVsStrInd++] = 'N';
							visSVsString[visSVsStrInd++] = 'W';
						}
						visSVsString[visSVsStrInd++] = ' ';
					}
					if(SVDataFieldType == 3 && buf[0]){
						visSVsString[visSVsStrInd++] = 'C';
						visSVsString[visSVsStrInd++] = 'N';
					    visSVsString[visSVsStrInd++] = '0';
					    visSVsString[visSVsStrInd++] = '-';
					    visSVsString[visSVsStrInd++] = buf[0];
					    visSVsString[visSVsStrInd++] = buf[1];
					    visSVsString[visSVsStrInd++] = ' ';
					}
					visSVsString[visSVsStrInd++] = '|';
					SVDataFieldType++;
					if(SVDataFieldType == 4){ SVDataFieldType = 0; }
				}//parse satellite data
				else if(msgFieldNo == 3 + 4*numOfSVs + 1){
					//signalID field
				}
				//clear the buffer
				for(;bufInd > 0;bufInd--){
					buf[bufInd] = 0;
				}
				buf[bufInd] = 0;
				msgFieldNo++;
			}//parsing
			else{
				//continue filling the buffer
				buf[bufInd++] = msgBuf[i];
			}
			if(msgBuf[i] == '*'){
				switch(msgBuf[2]){
				case 'P': visSVsGPSInd = visSVsStrInd;break;
				case 'L': visSVsGLOInd = visSVsStrInd;break;
				case 'A':break;
				case 'B':break;
				}
				gotCorrMesg=1;
				return i;
			}
//			if(msgBuf[i] == '*'){
//				//parsing stop;check checksum in message
//				checksum = calculateNMEAchecksum(msgBuf);
//				if( ((checksum &0xFF00) ==msgBuf[i+1])
//				    &&((checksum &0x00FF) ==msgBuf[i+2])
//					&&msgBuf[i+3] ==13 &&msgBuf ==14     ){
//
//					WrongChecksum = 0;
//				}
//				else{
//					WrongChecksum = 1;
//				}
//			}
		}
	}
//end of GSV message parser
//start of GLL parser
	if(msgBuf[3]=='G' && msgBuf[4]=='L' && msgBuf[5]=='L'){
		uint8_t buf[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
		uint8_t addtnlBuf[8] = {0,0,0,0,0,0,0,0};//this buffer is used for parsing integers in data fields
		uint8_t bufInd = 0;
		uint8_t msgFieldNo = 1;
		uint8_t valid = 0;

		for(uint8_t i=7;i<size;i++)
		{
			if(msgBuf[i] == ',' || msgBuf[i] == '*'){
				//parse field of data depending on its No.
				if(msgFieldNo == 1){
					//latitude
					addtnlBuf[0] = buf[0];
					addtnlBuf[1] = buf[1];
					latitude[0] = atoi(addtnlBuf);
					addtnlBuf[0] = buf[2];
					addtnlBuf[1] = buf[3];
					latitude[1] = atoi(addtnlBuf);
					addtnlBuf[0] = '0';
					addtnlBuf[1] = '.';

					for(uint8_t j=0;j<5;j++){
						addtnlBuf[2+j] = buf[5+j];
					}
					latitude[2] =  (uint32_t)(atoff(addtnlBuf) *60);
					latitude[3]=((uint32_t)(atof(addtnlBuf)*60*100000) -latitude[2]*100000)/1000;
					//clear additional buufer
					for(uint8_t j=0;j<8;j++){
						addtnlBuf[j] = 0;
					}
				}
				else if(msgFieldNo == 2){
					NS = buf[0];
				}
				else if(msgFieldNo == 3){
					//Longitude
					addtnlBuf[0] = buf[0];
					addtnlBuf[1] = buf[1];
					addtnlBuf[2] = buf[2];
					longitude[0] = atoi(addtnlBuf);
					addtnlBuf[0] = buf[3];
					addtnlBuf[1] = buf[4];
					addtnlBuf[2] = 0;
					longitude[1] = atoi(addtnlBuf);
					addtnlBuf[0] = '0';
					addtnlBuf[1] = '.';

					for(uint8_t j=0;j<5;j++){
						addtnlBuf[2+j] = buf[6+j];
					}
					longitude[2] =  (uint8_t)(atoff(addtnlBuf) *60);
					longitude[3]=( (uint32_t)(atof(addtnlBuf)*60*100000) -latitude[2]*100000 )/1000;

					for(uint8_t j=0;j<8;j++){
						addtnlBuf[j] = 0;
					}
			    }
				else if(msgFieldNo == 4){
					EW = buf[0];
				}
				else if(msgFieldNo == 6){
					//parse this field to make sure position fix is valid
					if(buf[0] == 'A'){ valid = 1; }
				}

				//clear the data field
				for(;bufInd > 0;bufInd--){
					buf[bufInd] = 0;
				}
				buf[bufInd] = 0;
				msgFieldNo++;
			}
			else{
				buf[bufInd++] = msgBuf[i];
			}
			if(msgBuf[i] == '*'){
				//end of parsing
				if(valid){
					gotCorrMesg = 1;
				}
				return i;
			}
		}//parsing loop
	}//GLL message parser

	return 0;// just to fix warning and continue searching for NMEA messages
}
//this callback activates when MCU gets any data from any uart
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t size) {
	if(huart->Instance == USART2){
		CDC_Transmit_FS(rxbuf, size);//send all data MCU gets via USB
		//parse all of NMEA messages
		for(uint16_t i=0;i<size;i++){
			if(rxbuf[i] == '$'){
				i += parseNmeaMessage(&rxbuf[i], (size-i)) + 4;
			}
		}
		HAL_UARTEx_ReceiveToIdle_IT(&huart2, rxbuf, 650);
	}
}
//NMEA checksum calculator. ptr should be pointer to the start '$' character
uint16_t calculateNMEAchecksum(uint16_t *ptr){
	uint8_t zeroToF[] = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	uint8_t checksum = 0;
	uint16_t res = 0;
	ptr++;//move from start of the message ('$') to next charachter
	while(*ptr != '*'){
		checksum = checksum ^ *ptr;
		ptr++;
	}
	res = (((uint16_t)(zeroToF[ (checksum & 0xF0) >> 4 ])) << 8) | (zeroToF[checksum & 0x0F]);
	return res;
}
//UBX checksum calculator
//we need to calculate checksum in a different situations, so the calculation is
//organised in separate function
//len must be 1 or greater. else checksum is 0, 0
uint16_t calculateUBXCheckSum(uint8_t *ptr, uint8_t len){
	uint32_t ck_b = 0;
	uint32_t ck_a = 0;
	uint8_t *i;
	for(i=ptr;i < ptr+len;i++){// !!!check this place if some problems occur
		ck_a += *i;
		ck_b += ck_a;
	}
	return ( (uint16_t)(ck_a & 0xFF) << 8 ) | (uint16_t)(ck_b & 0xFF);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_DEVICE_Init();
  MX_USART2_UART_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  uint8_t *ptr;
  ptr = CoordsString;
  HAL_UARTEx_ReceiveToIdle_IT(&huart2, rxbuf, 300);

  ST7735_Init();
  ST7735_Backlight_On();
  ST7735_SetRotation(0);
  ST7735_FillScreen(ST7735_BLACK);
  HAL_Delay(100);
  parseNmeaMessage(rxbuf, 50);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  if(gotCorrMesg){
		  ST7735_FillRectangle(0, 0, 128, 90, ST7735_BLACK);

		  ST7735_DrawString(0, 0, "Latitude:", Font_11x18, ST7735_WHITE, ST7735_BLACK);
		  sprintf(CoordsString, "%d*%d'%d.%d\"", latitude[0],latitude[1],latitude[2],latitude[3]);
		  do{
			  ptr++;
		  }
		  while(*ptr);
		  *ptr = NS;//adds north/south indicator to the coordinates
		  ST7735_DrawString(0, 18, CoordsString, Font_11x18, ST7735_WHITE, ST7735_BLACK);

		  ST7735_DrawString(0, 54, "Longitude:", Font_11x18, ST7735_WHITE, ST7735_BLACK);
		  sprintf(CoordsString, "%d*%d'%d.%d\"", longitude[0],longitude[1],longitude[2],longitude[3]);
		  ptr = CoordsString;
		  do{
			  ptr++;
		  }
		  while(*ptr);
		  *ptr = EW;//adds east/west indicator to the coordinates
		  ST7735_DrawString(0, 72, CoordsString, Font_11x18, ST7735_WHITE, ST7735_BLACK);

		  gotCorrMesg = 0;
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 144;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPI1_CS_GPIO_Port, SPI1_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, SPI1_RESET_Pin|SPI1_A0_Pin|SPI1_BL_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : SPI1_CS_Pin */
  GPIO_InitStruct.Pin = SPI1_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SPI1_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SPI1_RESET_Pin SPI1_A0_Pin SPI1_BL_Pin */
  GPIO_InitStruct.Pin = SPI1_RESET_Pin|SPI1_A0_Pin|SPI1_BL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
